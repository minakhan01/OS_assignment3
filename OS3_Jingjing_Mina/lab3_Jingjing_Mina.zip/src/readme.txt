a) Names of all the group members.
Jingjing Rong, Mina Khan

b) Instructions for compiling and executing your program(s). Include an example command line.
You will need to change line 8 and 9 in Main.java when depending on whether you want to use segmentation test file or paging file. Line 8 has “File file = new File("test_segmentation.txt”);”, and line 9 is “File file = new File("test_paging.txt”);”. Comment line 9, when testing segmentation (we have currently done this in the current file so you’ll run the segmentation testing file). Comment line 8 and uncommon line 9 when you need to run paging test file. You can also just change the file names.
Once you have the appropriate file names, use the following 2 terminal commands:
javac *.java
java Main.java

c) If your implementation does not work, you should also document the problems in the README file, preferably with your explanation of why it does not work and how you would solve it if you had more time.
We think everything works :)

d) If you did not implement certain features, you should list them as well.
We implemented everything.