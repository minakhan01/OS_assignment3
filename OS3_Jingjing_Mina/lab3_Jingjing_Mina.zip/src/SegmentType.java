// segment types
public enum SegmentType {
	TEXT, 
	STACK, 
	HEAP;
}
